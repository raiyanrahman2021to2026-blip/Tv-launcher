# Made with cleanyourtv

Launchers, ports and add-ons people built on top of this repo, or with its prompt, that live in
their own repositories. The launcher in `launcher/` stays small on purpose; this page is where the
bigger ideas go, with the people who made them.

Nothing here is reviewed or maintained by this repo. Read the project's own README, check which TV
it was built on, and treat it the way you'd treat any app you sideload. Each row links to the
project's own issue tracker.

| Project | What it is | Built on | By |
|---|---|---|---|
| [Stremio shelf, peek dock and calendar](https://github.com/benfirad/tv-vibehack) | A fork of the launcher with a Stremio poster shelf, a dock that peeks over playing content, a frosted settings panel and a calendar overlay | Android TV | [benfirad](https://github.com/benfirad) |
| [Hisense restyle](https://github.com/YouLop009/tv-vibehack/tree/style-modifications) | A six-column restyle with an app menu, a Wi-Fi picker in the header, daily greetings and four glass finishes | Hisense SmartTV 4K FFM, Android 12 | [YouLop009](https://github.com/YouLop009) |
| [webOS launcher](https://github.com/OmkarK97/webos-vibehack) | The same Apple TV-style home rebuilt as a webOS web app for LG TVs, installed through LG's Developer Mode, with a Home-button watcher that runs on another device | LG OLED C6, webOS 26 | [OmkarK97](https://github.com/OmkarK97) |
| [fire-tv-cleanup](https://github.com/itsmeterrylin/fire-tv-cleanup) | A fork aimed at Fire TV: debloat plus a launcher with a macOS-style dock | Fire TV | [itsmeterrylin](https://github.com/itsmeterrylin) |
| [Fire OS 6 Home watcher](https://github.com/ljis120301/tv-vibehack/tree/fire-tv-support) | Brings the launcher up over Amazon's home on a Fire TV Stick 4K, since Fire OS won't let it be replaced | Fire TV Stick 4K, Fire OS 6 | [ljis120301](https://github.com/ljis120301) |
| [Fire TV Glass](https://github.com/ivantrj/firetv-glass-launcher) | Debloat scripts and a small Glass launcher for Fire OS 8, which protects Amazon's home: an accessibility service brings Glass back whenever Amazon's home appears. Dock, hidden apps and wallpaper change without a rebuild | Fire TV Stick 4K (AFTKRT), Fire OS 8 / Android 11 | [ivantrj](https://github.com/ivantrj) |
| [Aurora screensaver and wallpaper](https://github.com/rakshajag13/tv-vibehack/tree/xiaomi-mitv-axso0-debloat-wallpaper) | A wallpaper behind the launcher and an "Aurora Clock" screensaver with drifting scenes and on-TV screensaver options | Xiaomi MiTV-AXSO0, Android TV 9 | [rakshajag13](https://github.com/rakshajag13) |
| [Control Center](https://github.com/samdegan2311/tv-vibehack/tree/pr/control-center) | A sleep timer, turn-off button, memory cleaner and sound-output switch behind the Settings pill, on top of a dock editor | Xiaomi MSSP3, Android TV 11 | [samdegan2311](https://github.com/samdegan2311) |
| [Navigation sounds](https://github.com/rocavence/tv-vibehack/tree/nav-sounds) | The launcher with its own soft click and select sounds, synthesised from a script | BenQ E55-735, Google TV 14 | [rocavence](https://github.com/rocavence) |
| [AirPlay receiver installer](https://github.com/nguyenduchoai/tv-vibehack/tree/feat/airplay-receiver) | A script that builds and installs an open-source AirPlay receiver next to the launcher, for iPhone mirroring | Xiaomi MiTV-AESP0, Android TV 9 | [nguyenduchoai](https://github.com/nguyenduchoai) |
| [Sony China launcher](https://github.com/roninriddle/tv-vibehack/tree/sony) ([issues](https://github.com/roninriddle/tv-vibehack/issues)) | A Sony-focused fork with Simplified Chinese, remote app ordering, two visible app rows, focus/ambient animations and an on-TV stock-home recovery shortcut; no Google services required | Sony K-85XR70 (China), Android 14 | [roninriddle](https://github.com/roninriddle) |
| [CleanMyTCL-Android9](https://github.com/eddysangalli/CleanMyTCL-Android9) | A fork specialised for TCL sets on Android TV 9: per-model profiles with a protected-package list, an ultralight launcher mode with on-TV settings and HDMI number keys, and published per-device benchmarks | TCL BeyondTV2, Realtek RTD2851, Android TV 9 | [eddysangalli](https://github.com/eddysangalli) |
| [CleanXiaomiTV](https://github.com/majnioui/CleanXiaomiTV) | A fork for one Xiaomi set: a liquid-glass home over the photo of the day, a now playing card, weather and AdGuard DNS | Xiaomi MiTV-MOOR2, Google TV 11 | [majnioui](https://github.com/majnioui) |
| [Rotating wallpapers and a Wallpaper picker](https://github.com/Alafazam/cleanyourtv/tree/axso2-launcher) | A folder of photos rotating behind Home every 30 minutes, a Wallpaper tile with a thumbnail picker, and an eight-app dock | Xiaomi MiTV-AXSO2, Android TV 9 | [Alafazam](https://github.com/Alafazam) |
| [tv-bookshelf](https://github.com/griffincockfoster56/tv-bookshelf) | A home screen that is a walnut bookcase: every app is a book, and OK pulls it off the shelf and opens it in 3D. About 60 fps on a 2.3 GB set | Sony BRAVIA 4K UR2, Android TV 10 | [griffincockfoster56](https://github.com/griffincockfoster56) |
| [Hisense 55U6K: reorder and weather](https://github.com/vlaship/cleanyourtv/tree/hisense-55u6k) | A fork with remote reordering (hold OK), the dock under the clock, a weather line and a click on every move | Hisense 55U6K, Google TV 11 | [vlaship](https://github.com/vlaship) |
| [KIDŌ](https://github.com/glidiandev/kido) | A command-center home screen built as its own app: a seven-segment clock, favorite apps as big panels and the rest as a honeycomb, live Wi-Fi and memory readouts, an HDMI input alert, three color themes and a drifting screensaver against burn-in. No internet permission | Sharp AQUOS 4K, Android TV 11 | [glidiandev](https://github.com/glidiandev) |
| [Cosy Home](https://github.com/oliverjwroberts/cosy-home-tv) | A home screen with a big clock over a valley that follows the real sunrise and sunset, live weather from Open-Meteo, a frosted-glass panel of apps and inputs on Down, and a slow pixel shift for OLED panels. Started from this repo's launcher | Philips 55OLED707, Android TV 11 | [oliverjwroberts](https://github.com/oliverjwroberts) |
| [Cast Fix](https://github.com/thayford/castfix) | Keeps casting from phones working on a Chromecast with Google TV after setupwraith is disabled for the launcher ([#361](https://github.com/Gathin23/cleanyourtv/issues/361)): at every boot it pairs with the TV's own Wireless debugging, lets the Cast receiver load its credentials from the setup wizard, then switches the wizard off again. No internet access | Chromecast with Google TV HD, Google TV 14 | [thayford](https://github.com/thayford) |
| [TidyTV](https://github.com/jolan94/tidytv) ([site](https://tidytv.winkle.dev)) | An Android phone app that applies this repo's per-model lists with no computer and no AI agent: backup first, `pm disable-user` only, an optional launcher install with rollback, and a one-tap restore. The lists are bundled from `examples/` and credited | TCL 32S5400, Android TV | [jolan94](https://github.com/jolan94) |
| [Clean Your TV Companion](https://github.com/gethari/clean-your-tv-companion) | A Windows, macOS and Linux app that connects to an Android TV or Google TV over ADB, checks its setup and compares the installed apps with the community lists. Runs locally, no account; the preview only inspects, changes are on its roadmap | Android TV / Google TV; tested on TCL Q6K | [gethari](https://github.com/gethari) |
| [Glass and day/night on a Polytron](https://github.com/andikatuluspangestu/cleanyourtv/tree/polytron-glass-launcher) | The launcher with a frosted-glass dock over a blurred wallpaper, day and night wallpapers that crossfade at set hours, a Recents tool and a Wi-Fi panel. No internet permission | Polytron 2K (MediaTek mt5867), Android TV 11 | [andikatuluspangestu](https://github.com/andikatuluspangestu) |
| [TV Remote](https://github.com/HoangTran0410/tv-remote) | A phone, desktop and web remote over ADB with no server or account; its Optimize TV applies this repo's lists with an undo and checks where Home lands after a launcher swap | FPT Play 650 (Android TV 14), Sony BRAVIA (Android 9) | [HoangTran0410](https://github.com/HoangTran0410) |
| [MYO Launcher](https://github.com/faustinoaq/myo-launcher) | A minimal, ad-free home screen for cheap Android TVs, replacing the ad-filled Zeasn launcher | MYO TV (HiSilicon Hi3751V350, Android 14, 1 GB RAM) | [faustinoaq](https://github.com/faustinoaq) |
| [CleanTV](https://github.com/0x006E/cleantv) | A launcher started from this one, with Xiaomi USB IR blaster control of cable/DTH set-top boxes, live channel rails and an encrypted LAN companion remote | Xiaomi MiTV-AXSO0 (Mi TV 4A 43"), Android TV 9 | [0x006E](https://github.com/0x006E) |

## Add yours

Open a pull request that adds one row. The rules are short:

- It is open source, and the link goes to a repository or branch people can read and build.
- It says which TV or platform it was built and tested on.
- It does not collect data or phone home beyond what it says on its own README.
- It is yours, or you have the author's blessing to list it.

A screenshot in the PR description is appreciated and will be linked from the row. If the project
is a fork of this repo, say what it changes; if it is something new made from `PROMPT.md`, say so,
those are the most fun to read.
