package com.gathin.tvhome;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class WeatherTest {
    @Test
    public void wmoCodesFallIntoTheShownWords() {
        assertEquals(Weather.CLEAR, Weather.group(0));
        assertEquals(Weather.PARTLY, Weather.group(1));
        assertEquals(Weather.PARTLY, Weather.group(2));
        assertEquals(Weather.CLOUDY, Weather.group(3));
        assertEquals(Weather.FOG, Weather.group(45));
        assertEquals(Weather.DRIZZLE, Weather.group(53));
        assertEquals(Weather.RAIN, Weather.group(63));
        assertEquals(Weather.RAIN, Weather.group(81));
        assertEquals(Weather.SNOW, Weather.group(73));
        assertEquals(Weather.SNOW, Weather.group(86));
        assertEquals(Weather.STORM, Weather.group(95));
        assertEquals(Weather.CLOUDY, Weather.group(-1));
        assertEquals(Weather.CLOUDY, Weather.group(1234));
    }

    @Test
    public void temperaturesAreWholeDegrees() {
        assertEquals("21\u00B0", Weather.format(20.6, false));
        assertEquals("-3\u00B0", Weather.format(-2.6, false));
        assertEquals("0\u00B0", Weather.format(-0.2, false));
        assertEquals("70\u00B0", Weather.format(21.0, true));
        assertEquals("32\u00B0", Weather.format(0.0, true));
    }

    @Test
    public void placeLabelsSkipRepeatedOrEmptyParts() {
        assertEquals("Paris, \u00CEle-de-France, France", Weather.label("Paris", "\u00CEle-de-France", "France"));
        assertEquals("Singapore, Singapore", Weather.label("Singapore", "Singapore", "Singapore"));
        assertEquals("Berlin, Germany", Weather.label("Berlin", "", "Germany"));
    }
}
