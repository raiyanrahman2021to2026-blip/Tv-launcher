package com.gathin.tvhome;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;
import org.junit.Test;

public class ToolsLogicTest {
    @Test
    public void onlyRealPackageNamesPassTheShellGate() {
        assertTrue(ToolsLogic.isPackageName("com.tcl.bi"));
        assertTrue(ToolsLogic.isPackageName("tv.anoki.acr.anokiacroptin"));
        assertFalse(ToolsLogic.isPackageName("com.tcl.bi; rm -rf /"));
        assertFalse(ToolsLogic.isPackageName("com.tcl.bi && reboot"));
        assertFalse(ToolsLogic.isPackageName("nodots"));
        assertFalse(ToolsLogic.isPackageName("$(id).x"));
        assertFalse(ToolsLogic.isPackageName(""));
        assertFalse(ToolsLogic.isPackageName(null));
    }

    @Test
    public void debloatListsSkipCommentsRepeatsAndJunk() {
        List<ToolsLogic.Line> l = ToolsLogic.parseDebloat(
                "# header\n\ncom.a.b\tfirst note\ncom.a.b\trepeat\ncom.c.d\nnot a package\n   com.e.f \tnote f\n");
        assertEquals(3, l.size());
        assertEquals("com.a.b", l.get(0).pkg);
        assertEquals("first note", l.get(0).note);
        assertEquals("", l.get(1).note);
        assertEquals("com.e.f", l.get(2).pkg);
    }

    @Test
    public void matchScoreCountsSharedWords() {
        assertTrue(ToolsLogic.matchScore("tcl-g03-google-tv", "TCL Smart TV Pro", "G03_4K_GB", "TCL", "BeyondTV4")
                > ToolsLogic.matchScore("hisense-hg9", "Hisense HG9", "G03_4K_GB", "TCL", "BeyondTV4"));
        assertEquals(0, ToolsLogic.matchScore("a", "b", (String) null));
    }

    @Test
    public void youtubeLinksAreNormalised() {
        assertEquals("https://www.youtube.com/watch?v=dQw4w9WgXcQ", ToolsLogic.youtubeUrl("dQw4w9WgXcQ"));
        assertEquals("https://youtu.be/dQw4w9WgXcQ", ToolsLogic.youtubeUrl("youtu.be/dQw4w9WgXcQ"));
        assertEquals("https://www.youtube.com/@channel", ToolsLogic.youtubeUrl(" https://www.youtube.com/@channel "));
        assertNull(ToolsLogic.youtubeUrl("https://example.com/watch"));
        assertNull(ToolsLogic.youtubeUrl("hello"));
        assertNull(ToolsLogic.youtubeUrl(null));
    }

    @Test
    public void durationsAndFolderGuesses() {
        assertEquals("3:07", ToolsLogic.duration(187000));
        assertEquals("1:02:09", ToolsLogic.duration(3729000));
        assertEquals("0:00", ToolsLogic.duration(-5));
        assertEquals("Video", ToolsLogic.guessFolder("com.netflix.ninja"));
        assertEquals("Music", ToolsLogic.guessFolder("com.spotify.tv.android"));
        assertEquals("Other", ToolsLogic.guessFolder("com.example.thing"));
    }
}
