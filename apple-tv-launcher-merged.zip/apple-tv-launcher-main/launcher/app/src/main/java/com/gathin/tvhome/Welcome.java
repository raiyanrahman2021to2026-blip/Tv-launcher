package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Date;

/**
 * An optional welcome screen when the launcher starts and goodbye screen before the Sleep row turns the TV off.
 * Both are off until switched on in More tools. They are screens of this launcher: the TV's own boot animation
 * and its power-off screen belong to the system and cannot be changed from an app.
 */
final class Welcome {
    private static final String PREFS = "welcome", K_START = "start", K_BYE = "bye";
    private static boolean played;   // once per run of the launcher, so recreate() does not repeat it

    private Welcome() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void playStartup(Activity a) {
        if (played || !prefs(a).getBoolean(K_START, false)) return;
        played = true;
        View screen = overlay(a, "Welcome");
        screen.setAlpha(1f);
        screen.postDelayed(() -> screen.animate().alpha(0f).setDuration(700).withEndAction(() -> remove(screen)), 1400);
    }

    /** Fades to a goodbye screen, then runs {@code then} (which turns the TV off). */
    static void goodbye(Activity a, Runnable then) {
        if (!prefs(a).getBoolean(K_BYE, false)) {
            then.run();
            return;
        }
        View screen = overlay(a, "Goodnight");
        screen.setAlpha(0f);
        screen.animate().alpha(1f).setDuration(600).withEndAction(() -> screen.postDelayed(() -> {
            then.run();
            screen.postDelayed(() -> remove(screen), 2500);   // gone before the TV wakes again
        }, 700));
    }

    private static void remove(View screen) {
        ViewGroup parent = (ViewGroup) screen.getParent();
        if (parent != null) parent.removeView(screen);
    }

    private static View overlay(Activity a, String title) {
        float d = a.getResources().getDisplayMetrics().density;
        FrameLayout frame = new FrameLayout(a);
        frame.setBackgroundColor(Color.BLACK);
        frame.setClickable(true);
        frame.setTranslationZ(1000f * d);
        GradientDrawable glow = new GradientDrawable();
        glow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        glow.setGradientRadius(420f * d);
        glow.setColors(new int[]{0x66FFFFFF, 0x00000000});
        View halo = new View(a);
        halo.setBackground(glow);
        frame.addView(halo, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        TextView big = new TextView(a);
        big.setText(title);
        big.setTextColor(Color.WHITE);
        big.setTextSize(56f);
        big.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        big.setGravity(Gravity.CENTER);
        box.addView(big);
        TextView small = new TextView(a);
        small.setText(DateFormat.getTimeFormat(a).format(new Date()));
        small.setTextColor(0xB3FFFFFF);
        small.setTextSize(24f);
        small.setGravity(Gravity.CENTER);
        box.addView(small);
        frame.addView(box, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        a.addContentView(frame, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return frame;
    }

    static void showSettings(Activity a) {
        SharedPreferences p = prefs(a);
        String[] items = {
                "Welcome screen when Home starts: " + (p.getBoolean(K_START, false) ? "On" : "Off"),
                "Goodbye screen before Sleep: " + (p.getBoolean(K_BYE, false) ? "On" : "Off")
        };
        new AlertDialog.Builder(a)
                .setTitle("Welcome and goodbye screens")
                .setItems(items, (dialog, which) -> {
                    String key = which == 0 ? K_START : K_BYE;
                    p.edit().putBoolean(key, !p.getBoolean(key, false)).apply();
                    showSettings(a);
                })
                .setNegativeButton(android.R.string.ok, null)
                .show();
    }
}
