package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.util.Xml;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/** The latest world headlines (BBC News RSS), read only when the person opens News. Nothing is sent about the TV. */
final class News {
    private static final String FEED = "https://feeds.bbci.co.uk/news/world/rss.xml";
    private static final int MAX = 12;

    private News() { }

    static void show(Activity a) {
        Toast.makeText(a, "Loading headlines...", Toast.LENGTH_SHORT).show();
        Handler main = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            List<String> titles = fetch();
            main.post(() -> {
                if (a.isFinishing() || a.isDestroyed()) return;
                if (titles.isEmpty()) {
                    Toast.makeText(a, "Could not load the news. Check the TV's internet connection.", Toast.LENGTH_LONG).show();
                } else {
                    new AlertDialog.Builder(a)
                            .setTitle("World news")
                            .setItems(titles.toArray(new String[0]), null)
                            .setNegativeButton(android.R.string.cancel, null)
                            .show();
                }
            });
        }, "news").start();
    }

    private static List<String> fetch() {
        List<String> titles = new ArrayList<>();
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(FEED).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", "AppleTvLauncher/1.2 (Android TV launcher)");
            if (c.getResponseCode() != 200) return titles;
            try (InputStream in = c.getInputStream()) {
                XmlPullParser p = Xml.newPullParser();
                p.setInput(in, null);
                boolean inItem = false;
                for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT && titles.size() < MAX; e = p.next()) {
                    if (e == XmlPullParser.START_TAG) {
                        String name = p.getName();
                        if ("item".equals(name)) {
                            inItem = true;
                        } else if (inItem && "title".equals(name)) {
                            String t = p.nextText();
                            if (t != null && !t.trim().isEmpty()) titles.add(t.trim());
                        }
                    } else if (e == XmlPullParser.END_TAG && "item".equals(p.getName())) {
                        inItem = false;
                    }
                }
            }
        } catch (Exception ignored) {
            // offline or the feed is down: an empty list tells the person
        } finally {
            if (c != null) c.disconnect();
        }
        return titles;
    }
}
