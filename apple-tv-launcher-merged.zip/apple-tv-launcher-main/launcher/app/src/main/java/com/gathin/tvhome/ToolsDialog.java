package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;

/** Settings, More tools: everything beyond the home screen itself, in one list. */
final class ToolsDialog {
    private ToolsDialog() { }

    static void show(Activity a, Runnable weatherChanged) {
        String[] items = {
                "Recent apps",
                "Frequently used",
                "Recently installed",
                "Recently updated",
                "Smart folders",
                "Gaming hub",
                "Sleep timer",
                "News",
                a.getString(R.string.weather),
                "YouTube shortcuts",
                "Watchlist",
                "Local videos",
                "Remote battery",
                "Welcome and goodbye screens",
                "Clean up this TV",
                a.getString(R.string.setup_on_tv)
        };
        new AlertDialog.Builder(a)
                .setTitle(R.string.more_tools)
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0: AppTools.recent(a); break;
                        case 1: AppTools.frequent(a); break;
                        case 2: AppTools.recentlyInstalled(a); break;
                        case 3: AppTools.recentlyUpdated(a); break;
                        case 4: AppTools.folders(a); break;
                        case 5: AppTools.games(a); break;
                        case 6: SleepTimer.show(a); break;
                        case 7: News.show(a); break;
                        case 8: WeatherDialog.show(a, weatherChanged); break;
                        case 9: SavedListDialog.youtube(a); break;
                        case 10: SavedListDialog.watchlist(a); break;
                        case 11: LocalVideos.show(a); break;
                        case 12: RemoteBattery.show(a); break;
                        case 13: Welcome.showSettings(a); break;
                        case 14: Debloat.show(a); break;
                        default: SetupDialog.show(a); break;
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}
