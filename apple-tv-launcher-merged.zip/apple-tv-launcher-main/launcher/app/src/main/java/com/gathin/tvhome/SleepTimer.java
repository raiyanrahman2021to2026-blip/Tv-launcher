package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.Toast;

/** "Turn the TV off in 30 minutes": an alarm that survives this app being closed, but not a TV restart. */
final class SleepTimer {
    private static final String PREFS = "sleep_timer", KEY = "at";
    private static final int[] MINUTES = {15, 30, 45, 60, 90, 120};

    private SleepTimer() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static PendingIntent intent(Context c) {
        return PendingIntent.getBroadcast(c, 7, new Intent(c, SleepTimerReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** When the timer ends, or 0 when none is running. */
    static long endsAt(Context c) {
        long at = prefs(c).getLong(KEY, 0L);
        return at > System.currentTimeMillis() ? at : 0L;
    }

    static void clear(Context c) {
        prefs(c).edit().remove(KEY).apply();
    }

    private static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(intent(c));
        clear(c);
    }

    private static boolean start(Context c, int minutes) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return false;
        long at = System.currentTimeMillis() + minutes * 60_000L;
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, intent(c));
        prefs(c).edit().putLong(KEY, at).apply();
        return true;
    }

    static void show(Activity a) {
        if (!SleepService.available()) {
            new AlertDialog.Builder(a)
                    .setTitle("Sleep timer")
                    .setMessage("The timer needs the launcher's Sleep service, which is not switched on yet. "
                            + "Run More tools, Set up Home from this TV once, or press Sleep in the Settings menu to check it.")
                    .setPositiveButton(android.R.string.ok, null)
                    .show();
            return;
        }
        long end = endsAt(a);
        int extra = end > 0 ? 1 : 0;
        String[] items = new String[MINUTES.length + extra];
        for (int i = 0; i < MINUTES.length; i++) items[i] = MINUTES[i] + " minutes";
        if (extra == 1) items[items.length - 1] = "Cancel the timer";
        String title = end > 0
                ? "Sleep timer: " + Math.max(1, (end - System.currentTimeMillis() + 59_999) / 60_000) + " min left"
                : "Turn the TV off in...";
        new AlertDialog.Builder(a)
                .setTitle(title)
                .setItems(items, (d, which) -> {
                    if (which >= MINUTES.length) {
                        cancel(a);
                        Toast.makeText(a, "Sleep timer cancelled.", Toast.LENGTH_SHORT).show();
                    } else if (start(a, MINUTES[which])) {
                        Toast.makeText(a, "The TV will turn off in " + MINUTES[which] + " minutes.", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}
