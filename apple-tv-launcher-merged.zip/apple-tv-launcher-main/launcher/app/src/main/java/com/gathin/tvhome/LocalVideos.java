package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** The videos stored on this TV or a USB drive, opened in whatever player the TV has, plus the last few played. */
final class LocalVideos {
    private static final String PLAYED = "played";
    private static final int MAX = 150;

    private LocalVideos() { }

    private static String permission() {
        return Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_VIDEO" : "android.permission.READ_EXTERNAL_STORAGE";
    }

    static void show(Activity a) {
        if (a.checkSelfPermission(permission()) != PackageManager.PERMISSION_GRANTED) {
            new AlertDialog.Builder(a)
                    .setTitle("Local videos")
                    .setMessage("To list the videos on this TV the launcher needs permission to read them. "
                            + "\"Grant from this TV\" does it (USB debugging must be on), or ask Android on screen.")
                    .setPositiveButton("Grant from this TV", (d, w) -> {
                        List<String> commands = new ArrayList<>();
                        commands.add("pm grant " + a.getPackageName() + " " + permission());
                        LocalSetup.run(a, commands, (ok, message) -> {
                            if (ok) show(a);
                            else Toast.makeText(a, LocalSetup.PORT_CLOSED.equals(message)
                                    ? a.getString(R.string.setup_on_tv_port_closed)
                                    : "Could not grant it: " + message, Toast.LENGTH_LONG).show();
                        });
                    })
                    .setNeutralButton("Ask on screen", (d, w) -> a.requestPermissions(new String[]{permission()}, 88))
                    .setNegativeButton(android.R.string.cancel, null)
                    .show();
            return;
        }
        List<String> names = new ArrayList<>();
        List<Uri> uris = new ArrayList<>();
        int recent = SavedList.load(a, PLAYED).size();
        if (recent > 0) {
            names.add("Recently played (" + recent + ")");
            uris.add(null);
        }
        Uri base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] cols = {MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE, MediaStore.Video.Media.DURATION};
        try (Cursor c = a.getContentResolver().query(base, cols, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")) {
            while (c != null && c.moveToNext() && uris.size() < MAX) {
                names.add(c.getString(1) + "  (" + ToolsLogic.duration(c.getLong(2)) + ")");
                uris.add(ContentUris.withAppendedId(base, c.getLong(0)));
            }
        } catch (SecurityException | IllegalArgumentException e) {
            Toast.makeText(a, "This TV would not let the launcher read its videos.", Toast.LENGTH_LONG).show();
            return;
        }
        if (names.isEmpty()) {
            new AlertDialog.Builder(a).setTitle("Local videos")
                    .setMessage("No videos found on this TV or its USB drives.")
                    .setPositiveButton(android.R.string.ok, null).show();
            return;
        }
        new AlertDialog.Builder(a)
                .setTitle("Local videos")
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    Uri u = uris.get(which);
                    if (u == null) recentlyPlayed(a);
                    else play(a, u, names.get(which).replaceAll("\\s+\\([0-9:]+\\)$", ""));
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void recentlyPlayed(Activity a) {
        List<SavedList.Entry> list = SavedList.load(a, PLAYED);
        String[] names = new String[list.size()];
        for (int i = 0; i < names.length; i++) names[i] = list.get(i).name;
        new AlertDialog.Builder(a)
                .setTitle("Recently played")
                .setItems(names, (d, which) -> play(a, Uri.parse(list.get(which).value), list.get(which).name))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void play(Activity a, Uri uri, String name) {
        Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            a.startActivity(i);
            SavedList.addFirst(a, PLAYED, name, uri.toString());
        } catch (ActivityNotFoundException e) {
            Toast.makeText(a, "This TV has no video player. Install one such as VLC.", Toast.LENGTH_LONG).show();
        }
    }
}
