package com.gathin.tvhome;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Pure helpers for the More tools menu (no Android classes, so they are unit tested). */
final class ToolsLogic {
    private static final Pattern PACKAGE = Pattern.compile("^[A-Za-z_][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$");
    private static final Pattern YOUTUBE_ID = Pattern.compile("^[A-Za-z0-9_-]{11}$");

    private ToolsLogic() { }

    /** A real package name only: it ends up in a shell command, so nothing else may pass. */
    static boolean isPackageName(String s) {
        return s != null && s.length() <= 200 && PACKAGE.matcher(s).matches();
    }

    /** A package and the reason it may be disabled. */
    static final class Line {
        final String pkg;
        final String note;

        Line(String pkg, String note) {
            this.pkg = pkg;
            this.note = note;
        }
    }

    /** Lines of "package[TAB]note"; blanks, comments, repeats and anything that is not a package name are dropped. */
    static List<Line> parseDebloat(String text) {
        List<Line> out = new ArrayList<>();
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (String raw : text.split("\n")) {
            String s = raw.trim();
            if (s.isEmpty() || s.startsWith("#")) continue;
            int tab = s.indexOf('\t');
            String pkg = (tab < 0 ? s : s.substring(0, tab)).trim();
            String note = tab < 0 ? "" : s.substring(tab + 1).trim();
            if (isPackageName(pkg) && seen.add(pkg)) out.add(new Line(pkg, note));
        }
        return out;
    }

    /**
     * How well a bundled list fits this TV: one point for every word of the device's names (model, device,
     * product, brand) found in the list's folder name or title. Only a hint for sorting; the person picks.
     */
    static int matchScore(String slug, String title, String... deviceNames) {
        String haystack = (slug + " " + title).toLowerCase(Locale.ROOT);
        int score = 0;
        java.util.Set<String> counted = new java.util.HashSet<>();
        for (String name : deviceNames) {
            if (name == null) continue;
            for (String word : name.toLowerCase(Locale.ROOT).split("[^a-z0-9]+")) {
                if (word.length() >= 3 && counted.add(word) && haystack.contains(word)) score++;
            }
        }
        return score;
    }

    /** A YouTube link from what was typed: a full link, a youtu.be link or a bare 11-character video id; else null. */
    static String youtubeUrl(String input) {
        if (input == null) return null;
        String s = input.trim();
        if (YOUTUBE_ID.matcher(s).matches()) return "https://www.youtube.com/watch?v=" + s;
        String lower = s.toLowerCase(Locale.ROOT);
        if (lower.startsWith("youtu") || lower.startsWith("www.youtube") || lower.startsWith("m.youtube")) s = "https://" + s;
        lower = s.toLowerCase(Locale.ROOT);
        boolean https = lower.startsWith("https://") || lower.startsWith("http://");
        if (https && (lower.contains("youtube.com/") || lower.contains("youtu.be/"))) return s;
        return null;
    }

    /** "3:07" or "1:02:09". */
    static String duration(long millis) {
        long total = Math.max(0, millis / 1000);
        long h = total / 3600, m = total % 3600 / 60, sec = total % 60;
        return h > 0 ? String.format(Locale.US, "%d:%02d:%02d", h, m, sec) : String.format(Locale.US, "%d:%02d", m, sec);
    }

    /** A folder name for an app that Android has not categorised, guessed from its package name; else "Other". */
    static String guessFolder(String pkg) {
        String p = pkg.toLowerCase(Locale.ROOT);
        String[] video = {"netflix", "youtube", "hulu", "disney", "primevideo", "hbo", "plex", "kodi", "vlc",
                "hotstar", "crunchyroll", "twitch", "tubi", "pluto", "peacock", "paramount", "video", "iptv"};
        String[] music = {"spotify", "music", "deezer", "tidal", "audio", "radio", "podcast", "soundcloud"};
        for (String k : video) if (p.contains(k)) return "Video";
        for (String k : music) if (p.contains(k)) return "Music";
        return "Other";
    }
}
