package com.gathin.tvhome;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Process;
import android.provider.Settings;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Lists of the apps on this TV worked out in different ways: recent, frequent, recently installed,
 * folders by kind, and games. Each opens as a simple list; OK on an app starts it.
 */
final class AppTools {
    private static final long DAY = 24L * 60 * 60 * 1000;

    private AppTools() { }

    static final class Item {
        final String pkg;
        final String label;
        final int category;
        final boolean game;
        final boolean system;
        final long installed;
        final long updated;

        Item(String pkg, String label, int category, boolean game, boolean system, long installed, long updated) {
            this.pkg = pkg;
            this.label = label;
            this.category = category;
            this.game = game;
            this.system = system;
            this.installed = installed;
            this.updated = updated;
        }
    }

    /** Every app with a launcher entry, once per package, by name. */
    @SuppressWarnings("deprecation")
    static List<Item> launchable(Context c) {
        PackageManager pm = c.getPackageManager();
        Map<String, Item> map = new LinkedHashMap<>();
        for (String category : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            for (ResolveInfo ri : pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(category), 0)) {
                ActivityInfo ai = ri.activityInfo;
                if (ai == null) continue;
                String pkg = ai.packageName;
                if (pkg.equals(c.getPackageName()) || map.containsKey(pkg)) continue;
                ApplicationInfo app = ai.applicationInfo;
                String label = AppNames.get(c, pkg);
                if (label == null) label = Cards.cleanLabel(String.valueOf(ri.loadLabel(pm)), pkg);
                long installed = 0L, updated = 0L;
                try {
                    android.content.pm.PackageInfo info = pm.getPackageInfo(pkg, 0);
                    installed = info.firstInstallTime;
                    updated = info.lastUpdateTime;
                } catch (PackageManager.NameNotFoundException ignored) {
                    // not visible to this app: no install date
                }
                int cat = app == null ? ApplicationInfo.CATEGORY_UNDEFINED : app.category;
                boolean game = cat == ApplicationInfo.CATEGORY_GAME
                        || (app != null && (app.flags & ApplicationInfo.FLAG_IS_GAME) != 0);
                boolean system = app != null && (app.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                        && (app.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                map.put(pkg, new Item(pkg, label, cat, game, system, installed, updated));
            }
        }
        List<Item> list = new ArrayList<>(map.values());
        Collections.sort(list, (x, y) -> x.label.compareToIgnoreCase(y.label));
        return list;
    }

    static void open(Activity a, Item item) {
        PackageManager pm = a.getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(item.pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(item.pkg);
        if (i == null) {
            Toast.makeText(a, "Cannot open " + item.label, Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(a, "Cannot open " + item.label, Toast.LENGTH_SHORT).show();
        }
    }

    private static void showApps(Activity a, String title, List<Item> items, String empty, String neutral, Runnable neutralAction) {
        AlertDialog.Builder b = new AlertDialog.Builder(a).setTitle(title)
                .setNegativeButton(android.R.string.cancel, null);
        if (items.isEmpty()) {
            b.setMessage(empty);
        } else {
            String[] labels = new String[items.size()];
            for (int i = 0; i < labels.length; i++) labels[i] = items.get(i).label;
            b.setItems(labels, (d, which) -> open(a, items.get(which)));
            if (neutral != null) b.setNeutralButton(neutral, (d, w) -> neutralAction.run());
        }
        b.show();
    }

    // ---- lists that need no special access -------------------------------------------------------------

    static void recentlyInstalled(Activity a) {
        long since = System.currentTimeMillis() - 30 * DAY;
        List<Item> list = new ArrayList<>();
        for (Item i : launchable(a)) if (!i.system && i.installed >= since) list.add(i);
        Collections.sort(list, (x, y) -> Long.compare(y.installed, x.installed));
        showApps(a, "Recently installed", list.size() > 20 ? list.subList(0, 20) : list,
                "No app was installed in the last 30 days.", null, null);
    }

    /** Apps that got a new version in the last 14 days. */
    static void recentlyUpdated(Activity a) {
        long since = System.currentTimeMillis() - 14 * DAY;
        List<Item> list = new ArrayList<>();
        for (Item i : launchable(a)) if (!i.system && i.updated >= since && i.updated > i.installed) list.add(i);
        Collections.sort(list, (x, y) -> Long.compare(y.updated, x.updated));
        showApps(a, "Recently updated", list.size() > 20 ? list.subList(0, 20) : list,
                "No app was updated in the last 14 days.", null, null);
    }

    private static final String WATCH_PREFS = "update_watch", WATCH_KEY = "checked";
    private static final long WATCH_EVERY = 10L * 60 * 1000;

    /**
     * Names of the apps that were updated since the last check, newest first, at most five. Checks at most every
     * ten minutes (it reads every app's install record), and the very first call only sets the starting point.
     */
    static List<String> updatedSinceLastCheck(Context c) {
        android.content.SharedPreferences p = c.getSharedPreferences(WATCH_PREFS, Context.MODE_PRIVATE);
        long now = System.currentTimeMillis();
        long last = p.getLong(WATCH_KEY, 0L);
        List<String> names = new ArrayList<>();
        if (last != 0L && now >= last && now - last < WATCH_EVERY) return names;
        p.edit().putLong(WATCH_KEY, now).apply();
        if (last == 0L || now < last) return names;
        List<Item> fresh = new ArrayList<>();
        for (Item i : launchable(c)) if (!i.system && i.updated > last && i.updated > i.installed) fresh.add(i);
        Collections.sort(fresh, (x, y) -> Long.compare(y.updated, x.updated));
        for (Item i : fresh) if (names.size() < 5) names.add(i.label);
        return names;
    }

    static void games(Activity a) {
        List<Item> list = new ArrayList<>();
        for (Item i : launchable(a)) if (i.game) list.add(i);
        showApps(a, "Gaming hub", list, "No games found. Android marks an app as a game when its developer says so.", null, null);
    }

    /** Apps grouped by the kind Android records, with a package-name guess for the many TV apps that record none. */
    static void folders(Activity a) {
        Map<String, List<Item>> groups = new HashMap<>();
        for (Item i : launchable(a)) {
            String name = folderName(i);
            List<Item> g = groups.get(name);
            if (g == null) {
                g = new ArrayList<>();
                groups.put(name, g);
            }
            g.add(i);
        }
        List<String> names = new ArrayList<>(groups.keySet());
        Collections.sort(names, (x, y) -> {
            if (x.equals("Other") != y.equals("Other")) return x.equals("Other") ? 1 : -1;
            int c = Integer.compare(groups.get(y).size(), groups.get(x).size());
            return c != 0 ? c : x.compareTo(y);
        });
        String[] labels = new String[names.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = names.get(i) + " (" + groups.get(names.get(i)).size() + ")";
        new AlertDialog.Builder(a)
                .setTitle("Smart folders")
                .setItems(labels, (d, which) -> showApps(a, names.get(which), groups.get(names.get(which)), "", null, null))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static String folderName(Item i) {
        if (i.game) return "Games";
        switch (i.category) {
            case ApplicationInfo.CATEGORY_VIDEO: return "Video";
            case ApplicationInfo.CATEGORY_AUDIO: return "Music";
            case ApplicationInfo.CATEGORY_IMAGE: return "Photos";
            case ApplicationInfo.CATEGORY_SOCIAL: return "Social";
            case ApplicationInfo.CATEGORY_NEWS: return "News";
            case ApplicationInfo.CATEGORY_MAPS: return "Maps";
            case ApplicationInfo.CATEGORY_PRODUCTIVITY: return "Tools";
            default: return ToolsLogic.guessFolder(i.pkg);
        }
    }

    // ---- lists from usage statistics -------------------------------------------------------------------

    static boolean hasUsageAccess(Context c) {
        AppOpsManager ops = (AppOpsManager) c.getSystemService(Context.APP_OPS_SERVICE);
        if (ops == null) return false;
        int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
        if (mode == AppOpsManager.MODE_DEFAULT) {
            return c.checkCallingOrSelfPermission("android.permission.PACKAGE_USAGE_STATS") == PackageManager.PERMISSION_GRANTED;
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    private static void askUsageAccess(Activity a, Runnable again) {
        new AlertDialog.Builder(a)
                .setTitle("Allow usage access")
                .setMessage("Android keeps which apps you used. To list them, this launcher needs Usage access. "
                        + "\"Grant from this TV\" does it for you (USB debugging must be on); or open the settings and allow it there.")
                .setPositiveButton("Grant from this TV", (d, w) -> {
                    List<String> commands = new ArrayList<>();
                    commands.add("appops set " + a.getPackageName() + " GET_USAGE_STATS allow");
                    Toast.makeText(a, "Accept the USB debugging prompt if it appears.", Toast.LENGTH_LONG).show();
                    LocalSetup.run(a, commands, (ok, message) -> {
                        if (ok) {
                            again.run();
                        } else {
                            Toast.makeText(a, LocalSetup.PORT_CLOSED.equals(message)
                                    ? a.getString(R.string.setup_on_tv_port_closed)
                                    : "Could not grant it: " + message, Toast.LENGTH_LONG).show();
                        }
                    });
                })
                .setNeutralButton("Open settings", (d, w) -> {
                    try {
                        a.startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(a, "This TV has no Usage access screen. Use Grant from this TV.", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    /** Package to {last used, time in the foreground} over the last 30 days. */
    private static Map<String, long[]> usage(Context c) {
        Map<String, long[]> out = new HashMap<>();
        UsageStatsManager usm = (UsageStatsManager) c.getSystemService(Context.USAGE_STATS_SERVICE);
        if (usm == null) return out;
        long now = System.currentTimeMillis();
        List<UsageStats> stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, now - 30 * DAY, now);
        if (stats == null) return out;
        for (UsageStats s : stats) {
            long[] v = out.get(s.getPackageName());
            if (v == null) {
                v = new long[2];
                out.put(s.getPackageName(), v);
            }
            v[0] = Math.max(v[0], s.getLastTimeUsed());
            v[1] += s.getTotalTimeInForeground();
        }
        return out;
    }

    private static List<Item> ranked(Context c, boolean byRecent) {
        Map<String, long[]> use = usage(c);
        List<Item> list = new ArrayList<>();
        for (Item i : launchable(c)) {
            long[] v = use.get(i.pkg);
            if (v != null && (byRecent ? v[0] > 0 : v[1] > 0)) list.add(i);
        }
        int idx = byRecent ? 0 : 1;
        Collections.sort(list, (x, y) -> Long.compare(use.get(y.pkg)[idx], use.get(x.pkg)[idx]));
        return list.size() > 12 ? new ArrayList<>(list.subList(0, 12)) : list;
    }

    static void recent(Activity a) {
        if (!hasUsageAccess(a)) {
            askUsageAccess(a, () -> recent(a));
            return;
        }
        List<Item> list = ranked(a, true);
        ActivityManager am = (ActivityManager) a.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        if (am != null) am.getMemoryInfo(mi);
        String ram = mi.totalMem > 0
                ? String.format(Locale.US, "Memory: %.1f of %.1f GB in use", (mi.totalMem - mi.availMem) / 1e9, mi.totalMem / 1e9)
                : "Recent apps";
        showApps(a, ram, list, "No recent apps yet.", "Close all", () -> closeAll(a, list));
    }

    static void frequent(Activity a) {
        if (!hasUsageAccess(a)) {
            askUsageAccess(a, () -> frequent(a));
            return;
        }
        showApps(a, "Frequently used", ranked(a, false), "Nothing yet. Use some apps and look again.", null, null);
    }

    private static void closeAll(Activity a, List<Item> list) {
        List<String> commands = new ArrayList<>();
        for (Item i : list) if (ToolsLogic.isPackageName(i.pkg)) commands.add("am force-stop " + i.pkg);
        LocalSetup.run(a, commands, (ok, message) -> Toast.makeText(a, ok ? "Closed " + commands.size() + " apps."
                : LocalSetup.PORT_CLOSED.equals(message) ? a.getString(R.string.setup_on_tv_port_closed)
                : "Could not close them: " + message, Toast.LENGTH_LONG).show());
    }
}
