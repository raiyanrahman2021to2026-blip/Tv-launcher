package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** A short list of name and value pairs the person keeps (YouTube shortcuts, watchlist, recently played). */
final class SavedList {
    private static final String PREFS = "saved_lists";
    private static final int MAX = 100;

    static final class Entry {
        final String name;
        final String value;

        Entry(String name, String value) {
            this.name = name;
            this.value = value;
        }
    }

    private SavedList() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static List<Entry> load(Context c, String key) {
        List<Entry> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(key, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new Entry(o.optString("n", ""), o.optString("v", "")));
            }
        } catch (Exception ignored) {
            // damaged data: start again from an empty list
        }
        return out;
    }

    private static void save(Context c, String key, List<Entry> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Entry e : list) arr.put(new JSONObject().put("n", e.name).put("v", e.value));
            prefs(c).edit().putString(key, arr.toString()).apply();
        } catch (Exception ignored) {
            // cannot happen for plain strings
        }
    }

    /** Adds to the top; an entry with the same value moves up instead of repeating. */
    static void addFirst(Context c, String key, String name, String value) {
        List<Entry> list = load(c, key);
        for (int i = list.size() - 1; i >= 0; i--) if (list.get(i).value.equals(value)) list.remove(i);
        list.add(0, new Entry(name, value));
        while (list.size() > MAX) list.remove(list.size() - 1);
        save(c, key, list);
    }

    static void remove(Context c, String key, int index) {
        List<Entry> list = load(c, key);
        if (index >= 0 && index < list.size()) {
            list.remove(index);
            save(c, key, list);
        }
    }
}
