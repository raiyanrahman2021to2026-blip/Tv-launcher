package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Turns off the ad, tracking and demo apps a TV maker preinstalled, using the lists the project collected for
 * 120+ TVs (assets/debloat). Apps are DISABLED, never uninstalled, and a backup list lets one tap bring them back.
 * Runs through the TV's own debug port (see LocalSetup), so USB debugging must be on.
 */
final class Debloat {
    private static final String SETUP_WRAITH = "com.google.android.tungsten.setupwraith";
    private static final String GOOGLE_TV_HOME = "com.google.android.apps.tv.launcherx";
    private static final String BACKUP = "debloat_backup.txt";

    private Debloat() { }

    private static final class Tv {
        final String slug;
        final String name;
        final int count;
        final int score;

        Tv(String slug, String name, int count, int score) {
            this.slug = slug;
            this.name = name;
            this.count = count;
            this.score = score;
        }
    }

    static void show(Activity a) {
        int backedUp = readBackup(a).size();
        String[] items = {"Choose my TV and clean it up", "Bring back what was turned off (" + backedUp + ")"};
        new AlertDialog.Builder(a)
                .setTitle("Clean up this TV")
                .setItems(items, (d, which) -> {
                    if (which == 0) chooseTv(a);
                    else restore(a);
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static String asset(Activity a, String name) throws Exception {
        try (InputStream in = a.getAssets().open("debloat/" + name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            for (int n; (n = in.read(buf)) > 0; ) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }

    private static void chooseTv(Activity a) {
        List<Tv> tvs = new ArrayList<>();
        try {
            for (String line : asset(a, "index.txt").split("\n")) {
                String[] p = line.split("\\|");
                if (p.length < 3) continue;
                int score = ToolsLogic.matchScore(p[0], p[1], Build.MODEL, Build.DEVICE, Build.PRODUCT, Build.BRAND, Build.MANUFACTURER);
                tvs.add(new Tv(p[0], p[1], Integer.parseInt(p[2].trim()), score));
            }
        } catch (Exception e) {
            Toast.makeText(a, "The TV lists could not be read.", Toast.LENGTH_LONG).show();
            return;
        }
        Collections.sort(tvs, (x, y) -> y.score != x.score ? Integer.compare(y.score, x.score) : x.name.compareToIgnoreCase(y.name));
        String[] labels = new String[tvs.size()];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = (tvs.get(i).score > 0 && i < 3 ? "\u2605 " : "") + tvs.get(i).name + " (" + tvs.get(i).count + ")";
        }
        new AlertDialog.Builder(a)
                .setTitle("Pick your exact TV model")
                .setItems(labels, (d, which) -> confirm(a, tvs.get(which)))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static List<ToolsLogic.Line> wanted(Activity a, Tv tv) throws Exception {
        List<ToolsLogic.Line> out = new ArrayList<>();
        for (ToolsLogic.Line l : ToolsLogic.parseDebloat(asset(a, tv.slug + ".txt"))) {
            // Never the launcher itself; never the Google TV setup or home (Wi-Fi and Home can go with them).
            if (l.pkg.equals(a.getPackageName()) || l.pkg.equals(SETUP_WRAITH) || l.pkg.equals(GOOGLE_TV_HOME)) continue;
            out.add(l);
        }
        return out;
    }

    private static void confirm(Activity a, Tv tv) {
        List<ToolsLogic.Line> list;
        try {
            list = wanted(a, tv);
        } catch (Exception e) {
            Toast.makeText(a, "That list could not be read.", Toast.LENGTH_LONG).show();
            return;
        }
        final List<ToolsLogic.Line> apps = list;
        new AlertDialog.Builder(a)
                .setTitle(tv.name)
                .setMessage("Turn off " + apps.size() + " preinstalled apps (ads, tracking, demo mode)?\n\n"
                        + "Nothing is uninstalled, and \"Bring back what was turned off\" undoes it. "
                        + "Only do this if the name above is your exact TV: a list for another model can switch off something yours needs.\n\n"
                        + "Google TV's own setup and home screen are never touched here.")
                .setPositiveButton("Turn off", (d, w) -> apply(a, apps))
                .setNeutralButton("Review list", (d, w) -> review(a, tv, apps))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void review(Activity a, Tv tv, List<ToolsLogic.Line> apps) {
        String[] rows = new String[apps.size()];
        for (int i = 0; i < rows.length; i++) {
            ToolsLogic.Line l = apps.get(i);
            rows[i] = l.pkg + (l.note.isEmpty() ? "" : "\n" + l.note);
        }
        new AlertDialog.Builder(a)
                .setTitle("Will be turned off")
                .setItems(rows, null)
                .setPositiveButton("Back", (d, w) -> confirm(a, tv))
                .show();
    }

    private static void apply(Activity a, List<ToolsLogic.Line> apps) {
        List<String> commands = new ArrayList<>();
        Set<String> all = new LinkedHashSet<>(readBackup(a));
        for (ToolsLogic.Line l : apps) {
            commands.add("pm disable-user --user 0 " + l.pkg);
            all.add(l.pkg);
        }
        writeBackup(a, all);   // before running, so a half-finished run can still be undone
        Toast.makeText(a, "Working. Accept the USB debugging prompt if it appears.", Toast.LENGTH_LONG).show();
        LocalSetup.run(a, commands, (ok, message) -> Toast.makeText(a,
                ok ? "Done. Restart the TV once to be sure everything settled."
                        : LocalSetup.PORT_CLOSED.equals(message) ? a.getString(R.string.setup_on_tv_port_closed)
                        : "Did not finish: " + message, Toast.LENGTH_LONG).show());
    }

    private static void restore(Activity a) {
        Set<String> pkgs = readBackup(a);
        if (pkgs.isEmpty()) {
            Toast.makeText(a, "This launcher has not turned anything off.", Toast.LENGTH_LONG).show();
            return;
        }
        List<String> commands = new ArrayList<>();
        for (String p : pkgs) commands.add("pm enable " + p);
        LocalSetup.run(a, commands, (ok, message) -> {
            if (ok) {
                new File(a.getFilesDir(), BACKUP).delete();
                Toast.makeText(a, "Brought back " + commands.size() + " apps.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(a, LocalSetup.PORT_CLOSED.equals(message) ? a.getString(R.string.setup_on_tv_port_closed)
                        : "Did not finish: " + message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private static Set<String> readBackup(Activity a) {
        Set<String> out = new LinkedHashSet<>();
        File f = new File(a.getFilesDir(), BACKUP);
        if (!f.isFile()) return out;
        try (InputStream in = new java.io.FileInputStream(f)) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            for (int n; (n = in.read(buf)) > 0; ) bytes.write(buf, 0, n);
            for (String line : bytes.toString("UTF-8").split("\n")) if (ToolsLogic.isPackageName(line.trim())) out.add(line.trim());
        } catch (Exception ignored) {
            // unreadable backup: treated as empty
        }
        return out;
    }

    private static void writeBackup(Activity a, Set<String> pkgs) {
        try (FileOutputStream out = new FileOutputStream(new File(a.getFilesDir(), BACKUP))) {
            out.write(String.join("\n", pkgs).getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
            // cannot save the backup: the apps can still be turned back on in Settings, Apps
        }
    }
}
