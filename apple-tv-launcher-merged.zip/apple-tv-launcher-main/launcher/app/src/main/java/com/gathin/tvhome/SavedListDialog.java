package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.List;

/** YouTube shortcuts and the watchlist: two small lists the person fills in. */
final class SavedListDialog {
    private static final String YOUTUBE_TV = "com.google.android.youtube.tv";

    private SavedListDialog() { }

    static void youtube(Activity a) {
        show(a, "YouTube shortcuts", "youtube", true);
    }

    static void watchlist(Activity a) {
        show(a, "Watchlist", "watchlist", false);
    }

    private static void show(Activity a, String title, String key, boolean link) {
        List<SavedList.Entry> list = SavedList.load(a, key);
        String[] items = new String[list.size() + 1];
        items[0] = "+ Add";
        for (int i = 0; i < list.size(); i++) items[i + 1] = list.get(i).name;
        new AlertDialog.Builder(a)
                .setTitle(title)
                .setItems(items, (d, which) -> {
                    if (which == 0) add(a, title, key, link);
                    else entry(a, title, key, link, which - 1, list.get(which - 1));
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void add(Activity a, String title, String key, boolean link) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * a.getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        EditText name = new EditText(a);
        name.setSingleLine(true);
        name.setInputType(InputType.TYPE_CLASS_TEXT);
        name.setHint(link ? "Name" : "Title");
        box.addView(name);
        EditText url = new EditText(a);
        if (link) {
            url.setSingleLine(true);
            url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
            url.setHint("YouTube link or video id");
            box.addView(url);
        }
        new AlertDialog.Builder(a)
                .setTitle(title)
                .setView(box)
                .setPositiveButton("Save", (d, w) -> {
                    String n = name.getText().toString().trim();
                    if (link) {
                        String u = ToolsLogic.youtubeUrl(url.getText().toString());
                        if (u == null) {
                            Toast.makeText(a, "That is not a YouTube link.", Toast.LENGTH_LONG).show();
                            return;
                        }
                        SavedList.addFirst(a, key, n.isEmpty() ? u : n, u);
                    } else if (!n.isEmpty()) {
                        SavedList.addFirst(a, key, n, n);
                    }
                    show(a, title, key, link);
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void entry(Activity a, String title, String key, boolean link, int index, SavedList.Entry e) {
        String[] items = link ? new String[]{"Open", "Remove"} : new String[]{"Done, remove it"};
        new AlertDialog.Builder(a)
                .setTitle(e.name)
                .setItems(items, (d, which) -> {
                    if (link && which == 0) {
                        openYoutube(a, e.value);
                    } else {
                        SavedList.remove(a, key, index);
                        show(a, title, key, link);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void openYoutube(Activity a, String url) {
        Intent view = new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            a.startActivity(new Intent(view).setPackage(YOUTUBE_TV));
        } catch (ActivityNotFoundException first) {
            try {
                a.startActivity(view);
            } catch (ActivityNotFoundException second) {
                Toast.makeText(a, "No app on this TV can open that link.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
