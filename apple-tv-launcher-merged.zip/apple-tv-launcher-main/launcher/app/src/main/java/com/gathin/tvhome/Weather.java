package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Current weather next to the clock. Off until a city is chosen (Settings, Weather).
 * Data from Open-Meteo (https://open-meteo.com, no account or key); the only things sent are the
 * city name typed in a search and, afterwards, that city's coordinates. The idea of a weather chip
 * in the header comes from tvOS Launcher by techgenius (Apache License 2.0); this code is new.
 */
final class Weather {
    private static final String PREFS = "weather";
    private static final String K_ENABLED = "enabled", K_NAME = "name", K_LAT = "lat", K_LON = "lon",
            K_FAHRENHEIT = "fahrenheit", K_TEMP = "temp", K_CODE = "code", K_TIME = "time";
    private static final long STALE_MS = 30L * 60 * 1000;
    private static final String AGENT = "AppleTvLauncher/1.2 (Android TV launcher)";

    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "weather");
        t.setDaemon(true);
        return t;
    });
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final long RETRY_MS = 5L * 60 * 1000;
    private static volatile boolean refreshing;
    private static volatile long lastTry;

    /** A city found by a search. */
    static final class Place {
        final String label;
        final String name;
        final double lat;
        final double lon;

        Place(String label, String name, double lat, double lon) {
            this.label = label;
            this.name = name;
            this.lat = lat;
            this.lon = lon;
        }
    }

    interface SearchResult {
        /** On the main thread: places (maybe empty) or, when the search failed, an error and no places. */
        void onResult(List<Place> places, boolean failed);
    }

    private Weather() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) {
        SharedPreferences p = prefs(c);
        return p.getBoolean(K_ENABLED, false) && p.contains(K_LAT) && p.contains(K_LON);
    }

    static String placeName(Context c) {
        return prefs(c).getString(K_NAME, "");
    }

    /** Fahrenheit by default only where it is the local unit. */
    static boolean fahrenheit(Context c) {
        String country = Locale.getDefault().getCountry();
        boolean usual = "US".equals(country) || "LR".equals(country) || "MM".equals(country);
        return prefs(c).getBoolean(K_FAHRENHEIT, usual);
    }

    static void setFahrenheit(Context c, boolean fahrenheit) {
        prefs(c).edit().putBoolean(K_FAHRENHEIT, fahrenheit).apply();
    }

    static void setPlace(Context c, Place place) {
        prefs(c).edit().putBoolean(K_ENABLED, true).putString(K_NAME, place.name)
                .putFloat(K_LAT, (float) place.lat).putFloat(K_LON, (float) place.lon)
                .remove(K_TIME).remove(K_TEMP).remove(K_CODE).apply();
        lastTry = 0L;   // a new city is fetched at once
    }

    static void turnOff(Context c) {
        prefs(c).edit().putBoolean(K_ENABLED, false).apply();
    }

    /** "21\u00B0 Clear" from the last reading, or null when there is none yet. */
    static String text(Context c) {
        SharedPreferences p = prefs(c);
        if (!enabled(c) || !p.contains(K_TIME)) return null;
        return format(p.getFloat(K_TEMP, 0f), fahrenheit(c)) + " "
                + c.getString(conditionRes(group(p.getInt(K_CODE, -1))));
    }

    static boolean stale(Context c) {
        if (!enabled(c)) return false;
        long at = prefs(c).getLong(K_TIME, 0L);
        return System.currentTimeMillis() - at > STALE_MS || System.currentTimeMillis() < at;
    }

    /** Fetches the current weather for the chosen city; done runs on the main thread, also when it fails. */
    static void refresh(Context context, Runnable done) {
        long now = System.currentTimeMillis();
        if (refreshing || !enabled(context) || (now >= lastTry && now - lastTry < RETRY_MS)) return;
        refreshing = true;
        lastTry = now;
        Context app = context.getApplicationContext();
        SharedPreferences p = prefs(app);
        double lat = p.getFloat(K_LAT, 0f), lon = p.getFloat(K_LON, 0f);
        WORKER.execute(() -> {
            try {
                String body = get("https://api.open-meteo.com/v1/forecast?latitude=" + coord(lat)
                        + "&longitude=" + coord(lon) + "&current=temperature_2m,weather_code&timezone=auto");
                JSONObject current = new JSONObject(body).getJSONObject("current");
                p.edit().putFloat(K_TEMP, (float) current.getDouble("temperature_2m"))
                        .putInt(K_CODE, current.getInt("weather_code"))
                        .putLong(K_TIME, System.currentTimeMillis()).apply();
            } catch (Exception ignored) {
                // offline or the service is down: the last reading stays, and the next minute tick tries again
            } finally {
                refreshing = false;
            }
            if (done != null) MAIN.post(done);
        });
    }

    /** Looks a city up by name; the result is delivered on the main thread. */
    static void search(String query, SearchResult result) {
        WORKER.execute(() -> {
            List<Place> places = new ArrayList<>();
            boolean failed = false;
            try {
                String body = get("https://geocoding-api.open-meteo.com/v1/search?count=6&language=en&format=json&name="
                        + URLEncoder.encode(query.trim(), "UTF-8"));
                JSONArray found = new JSONObject(body).optJSONArray("results");
                for (int i = 0; found != null && i < found.length(); i++) {
                    JSONObject o = found.getJSONObject(i);
                    String name = o.optString("name", "");
                    if (name.isEmpty()) continue;
                    places.add(new Place(label(name, o.optString("admin1", ""), o.optString("country", "")),
                            name, o.getDouble("latitude"), o.getDouble("longitude")));
                }
            } catch (Exception e) {
                failed = true;
            }
            final boolean failure = failed;
            MAIN.post(() -> result.onResult(places, failure));
        });
    }

    static String label(String name, String region, String country) {
        StringBuilder sb = new StringBuilder(name);
        if (!region.isEmpty() && !region.equals(name)) sb.append(", ").append(region);
        if (!country.isEmpty()) sb.append(", ").append(country);
        return sb.toString();
    }

    private static String coord(double v) {
        return String.format(Locale.US, "%.4f", v);
    }

    private static String get(String address) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
        try {
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", AGENT);
            if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                for (int n; (n = in.read(buf)) > 0; ) {
                    out.write(buf, 0, n);
                    if (out.size() > 256 * 1024) throw new IOException("reply too large");
                }
                return out.toString("UTF-8");
            }
        } finally {
            c.disconnect();
        }
    }

    // ---- pure helpers (unit tested) ---------------------------------------------------------------

    static final int CLEAR = 0, PARTLY = 1, CLOUDY = 2, FOG = 3, DRIZZLE = 4, RAIN = 5, SNOW = 6, STORM = 7;

    /** Groups a WMO weather code, as Open-Meteo reports it, into one of the words shown. */
    static int group(int wmo) {
        if (wmo == 0) return CLEAR;
        if (wmo == 1 || wmo == 2) return PARTLY;
        if (wmo == 45 || wmo == 48) return FOG;
        if (wmo >= 51 && wmo <= 57) return DRIZZLE;
        if ((wmo >= 61 && wmo <= 67) || (wmo >= 80 && wmo <= 82)) return RAIN;
        if ((wmo >= 71 && wmo <= 77) || wmo == 85 || wmo == 86) return SNOW;
        if (wmo >= 95 && wmo <= 99) return STORM;
        return CLOUDY;
    }

    /** The temperature in whole degrees, "21\u00B0" or "70\u00B0". */
    static String format(double celsius, boolean fahrenheit) {
        double v = fahrenheit ? celsius * 9 / 5 + 32 : celsius;
        long rounded = Math.round(v);
        return rounded + "\u00B0";
    }

    private static int conditionRes(int group) {
        switch (group) {
            case CLEAR: return R.string.weather_clear;
            case PARTLY: return R.string.weather_partly;
            case FOG: return R.string.weather_fog;
            case DRIZZLE: return R.string.weather_drizzle;
            case RAIN: return R.string.weather_rain;
            case SNOW: return R.string.weather_snow;
            case STORM: return R.string.weather_storm;
            default: return R.string.weather_cloudy;
        }
    }
}
