package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** Hold OK on an app tile: its info, a name of the person's own, or uninstall. */
final class TileMenu {
    private TileMenu() { }

    static void show(Activity a, String pkg, String label, Runnable changed) {
        List<String> items = new ArrayList<>();
        items.add("App info");
        items.add("Rename");
        boolean renamed = AppNames.get(a, pkg) != null;
        if (renamed) items.add("Use the original name");
        items.add("Uninstall");
        new AlertDialog.Builder(a)
                .setTitle(label)
                .setItems(items.toArray(new String[0]), (d, which) -> {
                    String choice = items.get(which);
                    if ("App info".equals(choice)) {
                        open(a, new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg)));
                    } else if ("Rename".equals(choice)) {
                        rename(a, pkg, label, changed);
                    } else if ("Use the original name".equals(choice)) {
                        AppNames.reset(a, pkg);
                        changed.run();
                    } else {
                        open(a, new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg)));
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void rename(Activity a, String pkg, String label, Runnable changed) {
        EditText input = new EditText(a);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText(label);
        input.setSelection(label.length());
        new AlertDialog.Builder(a)
                .setTitle("Rename")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (!name.isEmpty()) {
                        AppNames.set(a, pkg, name);
                        changed.run();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void open(Activity a, Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            a.startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(a, "This TV cannot do that here.", Toast.LENGTH_LONG).show();
        }
    }
}
