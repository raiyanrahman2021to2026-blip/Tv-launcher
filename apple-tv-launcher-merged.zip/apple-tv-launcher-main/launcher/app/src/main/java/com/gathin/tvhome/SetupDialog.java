package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.widget.Toast;

import java.util.List;

/** The "Set up Home from this TV" prompt, shared by the Settings menu and the launcher settings screen. */
final class SetupDialog {
    private static final String GOOGLE_TV_HOME = "com.google.android.apps.tv.launcherx";

    private SetupDialog() { }

    static void show(Activity activity) {
        if (LocalSetup.isRunning()) return;
        new AlertDialog.Builder(activity)
                .setTitle(R.string.setup_on_tv)
                .setMessage(R.string.setup_on_tv_message)
                .setPositiveButton(R.string.setup_on_tv_run, (dialog, which) -> run(activity, false))
                .setNeutralButton(R.string.setup_on_tv_run_google, (dialog, which) -> run(activity, true))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void run(Activity activity, boolean switchOffGoogleTvHome) {
        Context app = activity.getApplicationContext();
        String component = new ComponentName(activity, MainActivity.class).flattenToString();
        List<String> commands = LocalSetup.homeSetupCommands(activity.getPackageName(), component,
                switchOffGoogleTvHome ? GOOGLE_TV_HOME : null);
        Toast.makeText(app, R.string.setup_on_tv_working, Toast.LENGTH_LONG).show();
        LocalSetup.run(app, commands, (success, message) -> {
            if (success) {
                Toast.makeText(app, R.string.setup_on_tv_done, Toast.LENGTH_LONG).show();
            } else if (LocalSetup.PORT_CLOSED.equals(message)) {
                Toast.makeText(app, R.string.setup_on_tv_port_closed, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(app, app.getString(R.string.setup_on_tv_failed, message), Toast.LENGTH_LONG).show();
            }
        });
    }
}
