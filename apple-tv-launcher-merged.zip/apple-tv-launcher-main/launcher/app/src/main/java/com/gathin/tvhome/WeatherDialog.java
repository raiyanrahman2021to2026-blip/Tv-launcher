package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputType;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

/** Settings, Weather: choose a city, switch the unit or turn the weather off. */
final class WeatherDialog {
    private WeatherDialog() { }

    /** changed runs whenever what the header shows may have changed. */
    static void show(Activity activity, Runnable changed) {
        if (!Weather.enabled(activity)) {
            askCity(activity, changed);
            return;
        }
        boolean f = Weather.fahrenheit(activity);
        String[] items = {
                activity.getString(R.string.weather_change_city),
                activity.getString(f ? R.string.weather_use_celsius : R.string.weather_use_fahrenheit),
                activity.getString(R.string.weather_turn_off)
        };
        new AlertDialog.Builder(activity)
                .setTitle(activity.getString(R.string.weather_title, Weather.placeName(activity)))
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        askCity(activity, changed);
                    } else if (which == 1) {
                        Weather.setFahrenheit(activity, !f);
                        changed.run();
                    } else {
                        Weather.turnOff(activity);
                        changed.run();
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static void askCity(Activity activity, Runnable changed) {
        EditText input = new EditText(activity);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_POSTAL_ADDRESS);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setHint(R.string.weather_city_hint);
        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(R.string.weather_city_title)
                .setView(input)
                .setPositiveButton(R.string.weather_search, null)   // set below, so a short entry keeps the dialog open
                .setNegativeButton(android.R.string.cancel, null)
                .create();
        dialog.setOnShowListener(d -> {
            Runnable search = () -> {
                String query = input.getText().toString().trim();
                if (query.length() < 2) return;
                dialog.dismiss();
                find(activity, query, changed);
            };
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> search.run());
            input.setOnEditorActionListener((v, action, event) -> {
                if (action != EditorInfo.IME_ACTION_SEARCH) return false;
                search.run();
                return true;
            });
        });
        dialog.show();
    }

    private static void find(Activity activity, String query, Runnable changed) {
        Toast.makeText(activity, R.string.weather_searching, Toast.LENGTH_SHORT).show();
        Weather.search(query, (places, failed) -> {
            if (activity.isFinishing() || activity.isDestroyed()) return;
            if (failed) {
                Toast.makeText(activity, R.string.weather_offline, Toast.LENGTH_LONG).show();
            } else if (places.isEmpty()) {
                Toast.makeText(activity, R.string.weather_no_match, Toast.LENGTH_LONG).show();
                askCity(activity, changed);
            } else {
                pick(activity, places, changed);
            }
        });
    }

    private static void pick(Activity activity, List<Weather.Place> places, Runnable changed) {
        String[] labels = new String[places.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = places.get(i).label;
        new AlertDialog.Builder(activity)
                .setTitle(R.string.weather_pick)
                .setItems(labels, (dialog, which) -> {
                    Weather.setPlace(activity, places.get(which));
                    Weather.refresh(activity, changed);
                    changed.run();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}
