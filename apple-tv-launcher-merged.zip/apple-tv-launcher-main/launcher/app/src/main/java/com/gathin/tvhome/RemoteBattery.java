package com.gathin.tvhome;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.hardware.BatteryState;
import android.os.Build;
import android.view.InputDevice;

import java.util.ArrayList;
import java.util.List;

/** The battery level of the remote, when Android exposes it (Android 12 or later, and only if the remote reports it). */
final class RemoteBattery {
    private RemoteBattery() { }

    static void show(Activity a) {
        List<String> lines = Build.VERSION.SDK_INT >= 31 ? levels() : new ArrayList<>();
        AlertDialog.Builder b = new AlertDialog.Builder(a).setTitle("Remote battery")
                .setPositiveButton(android.R.string.ok, null);
        if (lines.isEmpty()) {
            b.setMessage("This TV does not report a battery level for its remote. Android shares it only on "
                    + "version 12 or later, and only when the remote itself reports it.");
        } else {
            b.setItems(lines.toArray(new String[0]), null);
        }
        b.show();
    }

    @TargetApi(31)
    private static List<String> levels() {
        List<String> out = new ArrayList<>();
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice d = InputDevice.getDevice(id);
            if (d == null || d.isVirtual()) continue;
            BatteryState state = d.getBatteryState();
            if (state == null || !state.isPresent()) continue;
            float level = state.getCapacity();
            if (Float.isNaN(level)) continue;
            out.add(d.getName() + ": " + Math.round(level * 100) + "%");
        }
        return out;
    }
}
