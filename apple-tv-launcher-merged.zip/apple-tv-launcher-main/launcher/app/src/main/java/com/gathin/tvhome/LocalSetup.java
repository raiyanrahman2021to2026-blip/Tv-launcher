package com.gathin.tvhome;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.crypto.Cipher;

/**
 * Runs a few shell commands on this same TV through its own ADB port (127.0.0.1:5555), so Home can be
 * set up from the TV without a computer: grant the location permission, make this launcher Home and,
 * on Google TV, switch off the stock home screen.
 *
 * The ADB wire protocol handling (packets, the RSA token signature and the public key encoding) is
 * adapted from LocalAdb in tvOS Launcher by techgenius, Apache License 2.0
 * (https://github.com/techgenius1/tvOS-Launcher); see NOTICE-tvOS-Launcher.txt.
 *
 * The TV must have USB debugging (and Network debugging where the TV has it) turned on. The first time,
 * the TV asks "Allow USB debugging?" and the person has to accept it.
 */
final class LocalSetup {
    /** Result of a run; message is null on success, PORT_CLOSED when nothing listens on port 5555. */
    interface Callback {
        void onResult(boolean success, String message);
    }

    static final String PORT_CLOSED = "PORT_CLOSED";

    private static final int PORT = 5555;
    private static final int A_CNXN = 0x4e584e43;
    private static final int A_AUTH = 0x48545541;
    private static final int A_OPEN = 0x4e45504f;
    private static final int A_OKAY = 0x59414b4f;
    private static final int A_CLSE = 0x45534c43;
    private static final int A_WRTE = 0x45545257;
    private static final int A_VERSION = 0x01000000;
    private static final int MAX_PAYLOAD = 4096;
    private static final int AUTH_TOKEN = 1;
    private static final int AUTH_SIGNATURE = 2;
    private static final int AUTH_RSAPUBLICKEY = 3;

    // ASN.1 DigestInfo prefix for SHA-1; the 20-byte token from the TV follows it.
    private static final byte[] SHA1_DIGEST_INFO_PREFIX = {
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e,
            0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
    };

    private static volatile boolean running;

    private LocalSetup() { }

    /** True while a run is in progress, so a second press does not start another one. */
    static boolean isRunning() {
        return running;
    }

    /** Runs each command in its own shell stream on a background thread; the callback runs on the main thread. */
    static void run(Context context, List<String> commands, Callback callback) {
        if (running) return;
        running = true;
        Context app = context.getApplicationContext();
        Handler main = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            boolean ok = false;
            String message = null;
            try {
                runOnAnyHost(app, commands);
                ok = true;
            } catch (Exception e) {
                message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            } finally {
                running = false;
            }
            final boolean success = ok;
            final String text = message;
            main.post(() -> callback.onResult(success, text));
        }, "local-setup").start();
    }

    private static void runOnAnyHost(Context c, List<String> commands) throws Exception {
        Exception last = null;
        for (String host : new String[]{"127.0.0.1", lanIp()}) {
            if (host == null || !portOpen(host)) continue;
            try {
                runCommands(c, host, commands);
                return;
            } catch (Exception e) {
                last = e;
            }
        }
        if (last != null) throw last;
        throw new Exception(PORT_CLOSED);
    }

    private static boolean portOpen(String host) {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, PORT), 800);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static String lanIp() {
        try {
            for (java.net.NetworkInterface ni : Collections.list(java.net.NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (java.net.InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof java.net.Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) {
            // no network interface to read: the loopback address is tried on its own
        }
        return null;
    }

    private static void runCommands(Context c, String host, List<String> commands) throws Exception {
        KeyPair keys = keyPair(c);
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, PORT), 2500);
            socket.setSoTimeout(35000);   // time for the person to accept "Allow USB debugging?"
            DataInputStream in = new DataInputStream(socket.getInputStream());
            OutputStream out = socket.getOutputStream();
            send(out, A_CNXN, A_VERSION, MAX_PAYLOAD, "host::\0".getBytes(StandardCharsets.UTF_8));

            boolean signed = false;
            while (true) {
                Packet p = read(in);
                if (p.command == A_CNXN) break;
                if (p.command != A_AUTH || p.arg0 != AUTH_TOKEN) {
                    throw new Exception("Unexpected reply from the TV (" + p.command + ")");
                }
                if (!signed) {
                    signed = true;
                    send(out, A_AUTH, AUTH_SIGNATURE, 0, sign((RSAPrivateKey) keys.getPrivate(), p.data));
                } else {
                    // The TV did not know this key yet: offer it, which brings up the Allow prompt.
                    send(out, A_AUTH, AUTH_RSAPUBLICKEY, 0, publicKey((RSAPublicKey) keys.getPublic()));
                }
            }

            socket.setSoTimeout(15000);
            for (int i = 0; i < commands.size(); i++) {
                int id = i + 1;
                send(out, A_OPEN, id, 0, ("shell:" + commands.get(i) + "\0").getBytes(StandardCharsets.UTF_8));
                while (true) {
                    Packet p = read(in);
                    if (p.command == A_WRTE) {
                        send(out, A_OKAY, id, p.arg0, null);
                    } else if (p.command == A_CLSE) {
                        send(out, A_CLSE, id, p.arg0, null);
                        break;
                    }
                }
            }
        }
    }

    private static final class Packet {
        int command;
        int arg0;
        byte[] data;
    }

    private static void send(OutputStream out, int command, int arg0, int arg1, byte[] data) throws Exception {
        int len = data == null ? 0 : data.length;
        int sum = 0;
        for (int i = 0; i < len; i++) sum += data[i] & 0xFF;
        ByteBuffer header = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN);
        header.putInt(command).putInt(arg0).putInt(arg1).putInt(len).putInt(sum).putInt(~command);
        out.write(header.array());
        if (len > 0) out.write(data);
        out.flush();
    }

    private static Packet read(DataInputStream in) throws Exception {
        byte[] raw = new byte[24];
        in.readFully(raw);
        ByteBuffer header = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);
        Packet p = new Packet();
        p.command = header.getInt();
        p.arg0 = header.getInt();
        header.getInt();                // arg1
        int len = header.getInt();
        if (len < 0 || len > (1 << 20)) throw new Exception("Bad reply from the TV");
        p.data = new byte[len];
        if (len > 0) in.readFully(p.data);
        return p;
    }

    private static byte[] sign(RSAPrivateKey key, byte[] token) throws Exception {
        byte[] digestInfo = new byte[SHA1_DIGEST_INFO_PREFIX.length + token.length];
        System.arraycopy(SHA1_DIGEST_INFO_PREFIX, 0, digestInfo, 0, SHA1_DIGEST_INFO_PREFIX.length);
        System.arraycopy(token, 0, digestInfo, SHA1_DIGEST_INFO_PREFIX.length, token.length);
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(digestInfo);
    }

    /** Android's 524-byte RSAPublicKey struct, Base64 encoded, followed by a label. */
    private static byte[] publicKey(RSAPublicKey pub) {
        BigInteger n = pub.getModulus();
        BigInteger r32 = BigInteger.ONE.shiftLeft(32);
        BigInteger n0inv = r32.subtract(n.mod(r32).modInverse(r32)).mod(r32);
        BigInteger r = BigInteger.ONE.shiftLeft(2048);
        BigInteger rr = r.multiply(r).mod(n);
        ByteBuffer buf = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN);
        buf.putInt(64);                 // 2048 bits in 32-bit words
        buf.putInt((int) n0inv.longValue());
        buf.put(littleEndian256(n));
        buf.put(littleEndian256(rr));
        buf.putInt(pub.getPublicExponent().intValue());
        String text = Base64.encodeToString(buf.array(), Base64.NO_WRAP) + " apple-tv-launcher@tv\0";
        return text.getBytes(StandardCharsets.US_ASCII);
    }

    private static byte[] littleEndian256(BigInteger value) {
        byte[] big = value.toByteArray();
        byte[] little = new byte[256];
        int n = Math.min(256, big.length);
        for (int i = 0; i < n; i++) little[i] = big[big.length - 1 - i];
        return little;
    }

    /** The key the TV remembers once it has been allowed; kept in the app's private files. */
    private static KeyPair keyPair(Context c) throws Exception {
        File priv = new File(c.getFilesDir(), "local_adb.priv");
        File pub = new File(c.getFilesDir(), "local_adb.pub");
        if (priv.isFile() && pub.isFile()) {
            try {
                KeyFactory factory = KeyFactory.getInstance("RSA");
                return new KeyPair(
                        factory.generatePublic(new X509EncodedKeySpec(readAll(pub))),
                        factory.generatePrivate(new PKCS8EncodedKeySpec(readAll(priv))));
            } catch (Exception ignored) {
                // unreadable key files: make a new pair below
            }
        }
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048);
        KeyPair pair = generator.generateKeyPair();
        try (FileOutputStream o = new FileOutputStream(priv)) {
            o.write(pair.getPrivate().getEncoded());
        }
        try (FileOutputStream o = new FileOutputStream(pub)) {
            o.write(pair.getPublic().getEncoded());
        }
        return pair;
    }

    private static byte[] readAll(File f) throws Exception {
        byte[] bytes = new byte[(int) f.length()];
        try (FileInputStream in = new FileInputStream(f)) {
            int off = 0;
            while (off < bytes.length) {
                int n = in.read(bytes, off, bytes.length - off);
                if (n <= 0) break;
                off += n;
            }
        }
        return bytes;
    }

    /** The commands for Home setup on this launcher's own package; the stock-home step only when it is present. */
    static List<String> homeSetupCommands(String pkg, String component, String stockHomeToDisable) {
        List<String> list = new ArrayList<>();
        list.add("pm grant " + pkg + " android.permission.ACCESS_FINE_LOCATION");
        list.add("cmd package set-home-activity --user 0 " + component);
        if (stockHomeToDisable != null) list.add("pm disable-user --user 0 " + stockHomeToDisable);
        return list;
    }
}
