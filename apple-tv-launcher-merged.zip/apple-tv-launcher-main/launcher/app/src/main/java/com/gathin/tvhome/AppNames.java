package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;

/** Names the person gave to apps (hold OK on a tile, Rename); the app's own name is used when there is none. */
final class AppNames {
    private static final String PREFS = "app_names";

    private AppNames() { }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static String get(Context c, String pkg) {
        String s = prefs(c).getString(pkg, null);
        return s == null || s.trim().isEmpty() ? null : s;
    }

    static void set(Context c, String pkg, String name) {
        String clean = Cards.cleanLabel(name == null ? "" : name.trim(), pkg);
        if (clean.length() > 40) clean = clean.substring(0, 40);
        prefs(c).edit().putString(pkg, clean).apply();
    }

    static void reset(Context c, String pkg) {
        prefs(c).edit().remove(pkg).apply();
    }
}
